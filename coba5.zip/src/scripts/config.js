const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1', // URL API Story
  MAP_API_KEY: 'Du4PLKxSUoYiUTN8u8bl', // API Key untuk peta digital
};

export default CONFIG;
